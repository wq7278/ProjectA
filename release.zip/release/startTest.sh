java -Djava.library.path=. -jar ProcesssingToArduino-0.0.1-SNAPSHOT.jar
